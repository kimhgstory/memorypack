AI 학습팩 v1 — 2025-08-14

목적: 새 채팅/세션에서 같은 맥락을 재현.

1) 가장 간단: **02_SystemPrompt_KR_v1.txt**를 시스템/첫 메시지에 붙여넣기
2) 자세한 맥락: **01_MemoryPack_KR_v1.md**까지 함께 붙여넣기
3) RAG: **03_RAG_Chunks_v1.jsonl** 색인 후 관련 3~5줄만 주입
4) 스키마 검증: **04_Schema_OptionA.json**으로 결과 JSON 검증

권장: 한국어, 짧고 또렷하게 / temperature 0.2~0.4 / 근거 없으면 '모름' 규칙 유지
